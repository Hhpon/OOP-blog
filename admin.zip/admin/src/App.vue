<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>


<style>
html,
body {
  margin: 0;
  padding: 0;
}
</style>